package conexao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BancoDados {
	private static Connection con = null;
	private static final String servidor = "localhost";
	private static final String basedados = "basquete";
	private static final String usuario = "root";
	private static final String senha = "";
	
	public void conectar(){
		try {
			new com.mysql.jdbc.Driver();
			con = DriverManager.getConnection("jdbc:mysql://"+ servidor + "/" + basedados, usuario, senha);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public static void fechar() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static ResultSet receberDados(String SQL) {
		ResultSet dados = null;
		
		try {
			Statement st = (Statement) con.createStatement();
			dados = ((java.sql.Statement) st).executeQuery(SQL);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return dados;
	}
	
	public static void enviarDados(String SQL) {
		try {
			Statement st = (Statement) con.createStatement();
			((java.sql.Statement) st).execute(SQL);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}



