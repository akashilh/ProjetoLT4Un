package persistencia;

public class Time {

	String nome, escudo;
	int idtime;

	public int getIdtime() {
		return idtime;
	}

	public void setIdtime(int idtime) {
		this.idtime = idtime;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEscudo() {
		return escudo;
	}

	public void setEscudo(String escudo) {
		this.escudo = escudo;
	}
	
	
}
