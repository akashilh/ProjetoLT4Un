package persistencia;

public class Jogos {

	int ponutacao, idjogo;

	public int getPonutacao() {
		return ponutacao;
	}

	public void setPonutacao(int ponutacao) {
		this.ponutacao = ponutacao;
	}

	public int getIdjogo() {
		return idjogo;
	}

	public void setIdjogo(int idjogo) {
		this.idjogo = idjogo;
	}
	
	
}
