package dao;

import conexao.BancoDados;
import persistencia.Jogador;

public class jogadorDAO {

	
public void add (Jogador jogador) {
		
		BancoDados bd = new BancoDados();
		
		
		
		try {
			
		bd.conectar();
		
		bd.enviarDados("insert into Jogador('" + jogador.getNome() + "','" + jogador.getIdade() + "' ,"+ "'" + jogador.getPosicao() + "','" + jogador.getAltura() + "' ,'" + jogador.getPeso() + "')");
			
		
		}catch (Exception e) {
			System.err.println(e);
			// TODO: handle exception
		}	
	bd.fechar();}
}


