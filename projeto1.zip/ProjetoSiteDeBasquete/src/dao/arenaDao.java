package dao;
import conexao.BancoDados;
import persistencia.Arena;

public class arenaDao {
	
public void add (Arena arena) {
		
		BancoDados bd = new BancoDados();
		
		
		
		try {
			
		bd.conectar();
		
		bd.enviarDados("insert into Arena('" + arena.getNome() + "','" + arena.getCapacidade() + "','" + arena.getCidade() + "')");
			
		
		}catch (Exception e) {
			System.err.println(e);
			// TODO: handle exception
		}	
	bd.fechar();}
}


