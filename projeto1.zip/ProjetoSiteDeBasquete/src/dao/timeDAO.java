package dao;



import conexao.BancoDados;
import persistencia.Time;

public class timeDAO {

	public void add (Time time) {
		
		BancoDados bd = new BancoDados();
		
		
		
		try {
			
		bd.conectar();
		
		bd.enviarDados("insert into Times('" + time.getNome() + "','" + time.getEscudo() + "')");
			
		
		}catch (Exception e) {
			System.err.println(e);
			// TODO: handle exception
		}	
	bd.fechar();}
}
